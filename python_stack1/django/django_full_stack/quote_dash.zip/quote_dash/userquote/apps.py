from django.apps import AppConfig


class UserquoteConfig(AppConfig):
    name = 'userquote'
